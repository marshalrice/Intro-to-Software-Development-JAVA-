package cpsc2150.extendedConnectX;

import cpsc2150.extendedConnectX.models.GameBoard;
import cpsc2150.extendedConnectX.models.GameBoardMem;
import cpsc2150.extendedConnectX.models.IGameBoard;

import java.util.*;

public class GameScreen{
    private static IGameBoard board;
    private static int board_Rows;
    private static int board_Columns;
    private static int numPlayers;
    private static List<Character> players;

    public static void main(String[] args){
        //declare variables
        Scanner input = new Scanner(System.in);
        boolean gameOn = true;
        int c;
        int turn = 0;

        //game operation loop
        while(gameOn){
            // if new game...
            if(turn == 0){
                newGame(input);
            }
            System.out.println(board);
            c = getColumn(input, players.get(turn % numPlayers));

            board.placeToken(players.get(turn % numPlayers), c);


            if(board.checkForWin(c)){
                System.out.println(board);
                printWinMessage(players.get(turn % numPlayers));
                gameOn = playAgain(input);
                if(gameOn){
                    turn = 0;
                }
            }
            else if(board.checkTie()){
                gameOn = playAgain(input);
                if(gameOn){
                    turn = 0;
                }
            }else{
                ++turn;
            }
        }
    }

    private static void newGame(Scanner input) {
        //this function gets the necessary game data to start a new game
        //sets the rows, columns, tokens in a row to win, players, and game type for the new game
        board_Rows = getBoardRows(input);
        board_Columns = getBoardColumns(input);
        int board_Num_To_Win = getBoardNumToWin(input);
        getPlayers(input);
        char gameType = getGameType(input);

        if(isFastGame(gameType)){
            board = new GameBoardMem(board_Rows, board_Columns, board_Num_To_Win);
        }else{
            board = new GameBoard(board_Rows, board_Columns, board_Num_To_Win);
        }
    }

    private static boolean isFastGame(char gameType) {
        //a simplified version of an if statement
        // that checks if input wanted a fast game or not
        return gameType == 'F' || gameType == 'f';
    }

    private static int getColumn(Scanner input, char playerChar){
        System.out.println("Player " + playerChar + ", what column do you want to place your marker in?");
        int column = Integer.parseInt(input.nextLine());
        //loops until valid input is given
        while(!(column >= 0 && column < board.getNumColumns() && board.checkIfFree(column))){
            //print out respective error message
            if(column < 0){
                System.out.println("Column cannot be less than zero");
            }else if(column >= board.getNumColumns()){
                System.out.println("Column cannot be greater than " + (board.getNumColumns() - 1));
            }else{
                System.out.println("Column is full.");
            }
            //ask for input again
            System.out.println("Player " + playerChar + ", what column do you want to place your marker in?");
            column = Integer.parseInt(input.nextLine());
        }
        //returns a valid column
        return column;
    }

    private static boolean playAgain(Scanner input){
        System.out.println("Would you like to play again? Y/N");
        char inputChar = input.nextLine().charAt(0);
        while(!(inputChar == 'Y' || inputChar == 'N' || inputChar == 'y' || inputChar == 'n')){
            System.out.println("Would you like to play again? Y/N");
            inputChar = input.nextLine().charAt(0);
        }
        return inputChar == 'Y' || inputChar == 'y';
    }


    private static void getPlayers(Scanner input){
        //variable declarations

        final int MIN_PLAYERS = 2;
        final int MAX_PlAYERS = 10;
        char tempChar;
        System.out.println("How many players?");
        numPlayers = Integer.parseInt(input.nextLine());
        //checking number of players until a valid number is given
        while(!(numPlayers >= MIN_PLAYERS && numPlayers <= MAX_PlAYERS)){
            //send corresponding error message
            if(numPlayers < MIN_PLAYERS){
                System.out.println("Must be at least 2 players");
            }else{
                System.out.println("Must be 10 players or fewer");
            }
            //ask again for new input
            System.out.println("How many players?");
            numPlayers = Integer.parseInt(input.nextLine());
            //and then repeat until better info is given
        }

        //start getting characters

        //let's start with a fresh new list if there's still residual data from the previous game
        players = new ArrayList<>();

        //gets the new characters of size numPlayers
        for(int i = 0; i < numPlayers; ++i){
            //for every player...
            System.out.println("Enter the character to represent player " + (i + 1));
            //get the player
            tempChar = input.nextLine().charAt(0);
            //check the input for unique-ness
            while(players.contains(tempChar)){
                //loops until the input is good!
                System.out.println(tempChar + " is already taken as a player token!");
                System.out.println("Enter the character to represent player " + (i + 1));
                tempChar = input.nextLine().charAt(0);
            }
            //add the upper case version of the player's token character
            players.add(Character.toUpperCase(tempChar));
            //okay, time for the next player!
        }
        //all players should be acquired by this point.
    }

    private static int getBoardRows(Scanner input){
        //ask for input
        System.out.println("How many rows should be on the board?");
        int tempRows = Integer.parseInt(input.nextLine());
        //loops until input is valid
        while(!(tempRows >= IGameBoard.MIN_ROWS && tempRows <= IGameBoard.MAX_ROWS)){
            //print out respective error message
            if(tempRows < IGameBoard.MIN_ROWS){
                System.out.println("Must be at least " + IGameBoard.MIN_ROWS + " rows");
            }else{
                System.out.println("Must be " + IGameBoard.MAX_ROWS + " rows or fewer.");
            }
            //ask for input again
            System.out.println("How many rows should be on the board?");
            tempRows = Integer.parseInt(input.nextLine());
        }

        return tempRows;
    }

    private static int getBoardColumns(Scanner input){
        //ask for input
        System.out.println("How many columns should be on the board?");
        int tempColumns = Integer.parseInt(input.nextLine());
        //loops until input is valid
        while(!(tempColumns >= IGameBoard.MIN_COLUMNS && tempColumns <= IGameBoard.MAX_COLUMNS)){
            if(tempColumns < IGameBoard.MIN_COLUMNS){
                //print out respective error message
                System.out.println("Must be at least " + IGameBoard.MIN_COLUMNS+ " columns");
            }else{
                System.out.println("Must be " + IGameBoard.MAX_COLUMNS + " columns or fewer.");
            }
            //ask for input again
            System.out.println("How many columns should be on the board?");
            tempColumns = Integer.parseInt(input.nextLine());
        }
        return tempColumns;
    }

    private static int getBoardNumToWin(Scanner input){
        //ask for input
        System.out.println("How many in a row to win?");
        int tempNumToWin = Integer.parseInt(input.nextLine());
        //loops until input is valid
        while(!(tempNumToWin >= IGameBoard.MIN_NUM_TO_WIN && tempNumToWin <= IGameBoard.MAX_NUM_TO_WIN &&
                tempNumToWin < board_Rows && tempNumToWin < board_Columns)){
            //print out respective error message
            if(tempNumToWin < IGameBoard.MIN_NUM_TO_WIN){
                System.out.println("Must be at least " + IGameBoard.MIN_NUM_TO_WIN+ " tokens");
            }else{
                System.out.println("Must be " + IGameBoard.MAX_NUM_TO_WIN + " tokens or fewer.");
            }
            //ask for input again
            System.out.println("How many in a row to win?");
            tempNumToWin = Integer.parseInt(input.nextLine());
        }
        return tempNumToWin;
    }

    private static char getGameType(Scanner input){
        //ask for input
        System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m)?");
        char boardType = input.nextLine().charAt(0);
        //loops until input is valid
        while(!(boardType == 'M' || boardType == 'm' || boardType == 'F' || boardType == 'f')){
            //print out error message
            System.out.println("Please enter F or M");
            //ask for input again
            System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m)?");
            boardType = input.nextLine().charAt(0);
        }
        return boardType;
    }

    private static void printWinMessage(char winChar){
        System.out.println("Player " + winChar + " Won!");
    }


}
