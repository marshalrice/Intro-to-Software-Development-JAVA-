package cpsc2150.extendedConnectX.models;


abstract public class AbsGameBoard implements IGameBoard {
    /**
     * Description: toString
     *      This function overrides the Object.toString() function and prints the IGameBoard.
     *
     * @post
     *      [IGameBoard implementations] = AbsGameBoard.toString()
     * @return
     *      returns a string representation of the IGameBoard implementation
     * */
    @Override
    public String toString() {
        final int TEN = 10;
        StringBuilder boardString = new StringBuilder("|");
        //if it's a small board, do toString stuff.
        if(getNumColumns() < TEN){

            //sets the top of the board
            //for aesthetics

            for(int k = 0; k < getNumColumns(); ++k){
                boardString.append(k);
                boardString.append("|");
            }
            boardString.append('\n');


            //prints the rest of the board
            for(int i = 0; i < getNumRows(); ++i){
                //for every row...
                boardString.append("|");
                for(int j = 0; j < getNumColumns(); ++j){
                    //at every column in that row...
                    boardString.append(whatsAtPos(new BoardPosition(i, j)));
                    boardString.append("|");
                }
                //at the end of every row...
                boardString.append('\n');
            }
        }
        //else, do an adjusted version of toString
        else{

            //sets the top of the board
            //for aesthetics
            for(int k = 0; k < getNumColumns(); ++k){
                if(k < TEN){
                    boardString.append(" ");
                }
                boardString.append(k);
                boardString.append("|");
            }
            boardString.append('\n');


            //prints the rest of the board
            for(int i = 0; i < getNumRows(); ++i){
                //for every row...
                boardString.append("|");
                for(int j = 0; j < getNumColumns(); ++j){
                    //at every column in that row...
                    //format accordingly and...
                    boardString.append(" ");
                    //add the character
                    boardString.append(whatsAtPos(new BoardPosition(i, j)));
                    boardString.append("|");
                }
                //at the end of every row...
                boardString.append('\n');
            }
        }
        //return the board as a String
        return boardString.toString();
    }
}
