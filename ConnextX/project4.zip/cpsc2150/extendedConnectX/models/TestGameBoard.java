package cpsc2150.extendedConnectX.models;

import org.junit.Test;

import static junit.framework.TestCase.assertEquals;


public class TestGameBoard {
    private IGameBoard testBoard;


    public TestGameBoard(){
        testBoard = makeIGameBoard(3, 3, 3);
    }

    IGameBoard makeIGameBoard(int r, int c, int tfw){
        return new GameBoard(r, c, tfw);
    }


    //Test Cases

    //Constructor tests
    @Test
    public void constructor_min_board_size(){
        testBoard = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        String actual = testBoard.toString();
        String expected = "|0|1|2|\n| | | |\n| | | |\n| | | |\n";
        assertEquals(expected, actual);
    }
    //Distinction: tests the minimum board size


    @Test
    public void constructor_middle_board_size(){
        int ELEVEN = 11;
        testBoard = makeIGameBoard(ELEVEN, ELEVEN, ELEVEN);
        String actual = testBoard.toString();

        //prints the numbers at the top of the board
        StringBuilder expectedBuilder = new StringBuilder("|");
        for(int i = 0; i < ELEVEN; ++i){
            if(i < ELEVEN - 1){
                expectedBuilder.append(" ");
            }
            expectedBuilder.append(i);
            expectedBuilder.append("|");
        }
        //move to next line
        expectedBuilder.append("\n");
        //for every row...
        for(int i = 0; i < ELEVEN; ++i){
            //starts the row
            expectedBuilder.append('|');
            //makes the rest of the empty row
            expectedBuilder.append("  |".repeat(ELEVEN));
            //adds a new line to all lines but the last one
            expectedBuilder.append("\n");
        }
        String expected = expectedBuilder.toString();
        assertEquals(expected, actual);
    }
    //Distinction: tests a middle-sized board


    @Test
    public void constructor_max_board_size(){
        int TEN = 10;
        testBoard = makeIGameBoard(IGameBoard.MAX_ROWS, IGameBoard.MAX_COLUMNS, IGameBoard.MAX_NUM_TO_WIN);
        String actual = testBoard.toString();

        //prints the numbers at the top of the board
        StringBuilder expectedBuilder = new StringBuilder("|");
        for(int i = 0; i < IGameBoard.MAX_COLUMNS; ++i){
            if(i < TEN){
                expectedBuilder.append(" ");
            }
            expectedBuilder.append(i);
            expectedBuilder.append("|");
        }
        //move to next line
        expectedBuilder.append("\n");
        //for every row...
        for(int i = 0; i < IGameBoard.MAX_ROWS; ++i){
            //starts the row
            expectedBuilder.append('|');
            //makes the rest of the empty row
            expectedBuilder.append("  |".repeat(IGameBoard.MAX_COLUMNS));
            //adds a new line to all lines but the last one
            expectedBuilder.append("\n");
        }
        String expected = expectedBuilder.toString();
        assertEquals(expected, actual);
    }
    //Distinction: tests the maximum size on the board


    //checkIfFree tests
    @Test
    public void checkiffree_empty_column(){
         IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
         boolean actual = test.checkIfFree(0);
         boolean expected = true;
         assertEquals(expected, actual);
    }
    //Distinction: tests an empty column if it's free


    @Test
    public void checkiffree_partial_filled_column(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller,0);
        boolean actual = test.checkIfFree(0);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a partially filled column for availability


    @Test
    public void checkiffree_full_column(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            test.placeToken(charFiller, 0);
        }
        boolean actual = test.checkIfFree(0);
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests a full column for availability


    //checkHorizWin tests
    @Test
    public void checkhorizwin_no_win_condition(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            test.placeToken(charFiller, 0);
        }
        boolean actual = test.checkHorizWin(new BoardPosition(0,0),charFiller);
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests a failed case to see if non-qualifying conditions for horizontal wins work


    @Test
    public void checkhorizwin_bottom_of_board_condition(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_COLUMNS;++i){
            test.placeToken(charFiller, i);
        }
        boolean actual = test.checkHorizWin(new BoardPosition(IGameBoard.MIN_ROWS - 1,0),charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a horizontal win at the bottom of the board


    @Test
    public void checkhorizwin_middle_of_board_condition(){
        char charFiller = 'm';
        int middleRow = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_COLUMNS;++i){
            test.placeToken(charFiller, i);
            test.placeToken(charFiller, i);
        }
        boolean actual = test.checkHorizWin(new BoardPosition(middleRow,0),charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a horizontal win at a middle position on the board


    @Test
    public void checkhorizwin_top_of_board_condition(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(charFiller,i);
            }
        }
        boolean actual = test.checkHorizWin(new BoardPosition(0,IGameBoard.MIN_ROWS - 1),charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a horizontal win at the top of the board


    //checkVertWin tests
    @Test
    public void checkvertwin_not_a_vert_win(){
        char charFiller = 'm';
        int middleRow = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS - 1;++i){
            test.placeToken(charFiller, 0);
        }
        boolean actual = test.checkVertWin(new BoardPosition(middleRow,0), charFiller);
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests a purposefully failed case to see if non-qualifying conditions work


    @Test
    public void checkvertwin_left_most_column(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            test.placeToken(charFiller, 0);
        }
        boolean actual = test.checkVertWin(new BoardPosition(0,0), charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the first column for a vertical win


    @Test
    public void checkvertwin_middle_column(){
        char charFiller = 'm';
        int middleColumn = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            test.placeToken(charFiller, middleColumn);
        }
        boolean actual = test.checkVertWin(new BoardPosition(0,middleColumn), charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a middle column for a vertical win


    @Test
    public void checkvertwin_right_most_column(){
        char charFiller = 'm';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS,IGameBoard.MIN_NUM_TO_WIN);
        for (int i = 0; i < IGameBoard.MIN_ROWS;++i){
            test.placeToken(charFiller, IGameBoard.MIN_COLUMNS - 1);
        }
        boolean actual = test.checkVertWin(new BoardPosition(0,IGameBoard.MIN_COLUMNS - 1), charFiller);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the last column for a vertical win


    //whatsAtPos tests
    @Test
    public void whatsatpos_bottom_left_most_position(){
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        char actual = test.whatsAtPos(new BoardPosition(IGameBoard.MIN_ROWS - 1, 0));
        char expected = '0';
        assertEquals(expected, actual);
    }
    //Distinction: tests the bottom left most corner position on the board


    @Test
    public void whatsatpos_bottom_right_most_position(){
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        char actual = test.whatsAtPos(new BoardPosition(IGameBoard.MIN_ROWS - 1, IGameBoard.MIN_COLUMNS - 1));
        char expected = '0';
        assertEquals(Character.toString(expected), Character.toString(actual));
    }
    //Distinction: tests the bottom right most corner position on the board


    @Test
    public void whatsatpos_top_left_most_position(){
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        char actual = test.whatsAtPos(new BoardPosition(0, 0));
        char expected = '2';
        assertEquals(expected, actual);
    }
    //Distinction: tests the top left corner position on the board.


    @Test
    public void whatsatpos_top_right_most_position(){
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        char actual = test.whatsAtPos(new BoardPosition(0, IGameBoard.MIN_COLUMNS - 1));
        char expected = '2';
        assertEquals(expected, actual);
    }
    //Distinction: tests the top right corner position on the board


    @Test
    public void whatsatpos_middle_board_position(){
        int middleRow = 1;
        int middleCol = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        char actual = test.whatsAtPos(new BoardPosition(middleRow, middleCol));
        char expected = '1';
        assertEquals(expected, actual);
    }
    //Distinction: tests a middle position on the board


    //isPlayerAtPos tests
    @Test
    public void isplayeratpos_bottom_left_most_position(){
        char testChar = '0';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        boolean actual = test.isPlayerAtPos(new BoardPosition(IGameBoard.MIN_ROWS - 1, 0),testChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the bottom left corner of the board.


    @Test
    public void isplayeratpos_bottom_right_most_position(){
        char testChar = '0';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        boolean actual = test.isPlayerAtPos(new BoardPosition(IGameBoard.MIN_ROWS - 1, IGameBoard.MIN_COLUMNS - 1),testChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the bottom right corner of the board


    @Test
    public void isplayeratpos_top_left_most_position(){
        char testChar = '2';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        boolean actual = test.isPlayerAtPos(new BoardPosition(0,0),testChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the top left of the board


    @Test
    public void isplayeratpos_top_right_most_position(){
        char testChar = '2';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        boolean actual = test.isPlayerAtPos(new BoardPosition(0,IGameBoard.MIN_COLUMNS - 1),testChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests the top right of the board


    @Test
    public void isplayeratpos_middle_board_position(){
        int middleRow = 1;
        int middleCol = 1;
        char testChar = '1';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            for(int j = 0; j < IGameBoard.MIN_COLUMNS; ++j){
                test.placeToken(Integer.toString(j).charAt(0),i);
            }
        }
        boolean actual = test.isPlayerAtPos(new BoardPosition(middleRow, middleCol),testChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a middle position on the board


    //checkTie tests
    @Test
    public void checkTie_empty_board(){
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        boolean actual = test.checkTie();
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests if there's a tie when the board is empty


    @Test
    public void checkTie_partial_filled_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, 0);

        boolean actual = test.checkTie();
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests if there's a tie when there's a partially filled board


    @Test
    public void checkTie_full_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            test.placeToken(charFiller, i);
            test.placeToken(charFiller, i);
            test.placeToken(charFiller, i);

        }

        boolean actual = test.checkTie();
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests if there's a tie when there's full board


    @Test
    public void checkTie_full_column_not_full_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        for(int i = 0; i < IGameBoard.MIN_ROWS; ++i){
            test.placeToken(charFiller, 0);
        }
        boolean actual = test.checkTie();
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests if there's a tie when there's full column but not a full board since checkTie uses the
    //checkIfFree method.


    //checkDiagWin tests
    @Test
    public void checkdiagwin_no_win_condition(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, 0);
        boolean actual = test.checkDiagWin(new BoardPosition(IGameBoard.MIN_ROWS - 1, 0),charFiller);
        boolean expected = false;
        assertEquals(expected, actual);
    }
    //Distinction: tests a failed case to see if non-qualifying conditions work for diagonal wins.


    @Test
    public void checkdiagwin_bottom_left_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);

        //first column setup
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(0, IGameBoard.MIN_COLUMNS - 1),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a bottom left diagonal condition


    @Test
    public void checkdiagwin_bottom_right_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1 ;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);


        //first column setup
        test.placeToken(losingChar, 0);
        test.placeToken(losingChar, 0);
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(0, 0),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a bottom right diagonal condition


    @Test
    public void checkdiagwin_top_left_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1 ;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);


        //first column setup
        test.placeToken(losingChar, 0);
        test.placeToken(losingChar, 0);
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(IGameBoard.MIN_ROWS - 1, IGameBoard.MIN_COLUMNS - 1),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a top left diagonal condition


    @Test
    public void checkdiagwin_top_right_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);

        //first column setup
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(IGameBoard.MIN_ROWS - 1, 0),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a top right diagonal condition


    @Test
    public void checkdiagwin_middle_token_left_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1 ;
        int middleRow = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);


        //first column setup
        test.placeToken(losingChar, 0);
        test.placeToken(losingChar, 0);
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(middleRow, middleCol),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a left diagonal win condition when the token is in the middle

    @Test
    public void checkdiagwin_middle_token_right_diagonal(){
        char winningChar = 'O';
        char losingChar = 'X';
        int middleCol = 1;
        int middleRow = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);

        //first column setup
        test.placeToken(winningChar, 0);

        //middle column setup
        test.placeToken(losingChar, middleCol);
        test.placeToken(winningChar, middleCol);

        //right column setup
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(losingChar, IGameBoard.MIN_COLUMNS - 1);
        test.placeToken(winningChar, IGameBoard.MIN_COLUMNS - 1);


        boolean actual = test.checkDiagWin(new BoardPosition(middleRow, middleCol),winningChar);
        boolean expected = true;
        assertEquals(expected, actual);
    }
    //Distinction: tests a right diagonal win condition when the token is in the middle


    //placeToken tests
    @Test
    public void placeToken_first_column_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, 0);
        String actual = test.toString();
        String expected = "|0|1|2|\n" +
                          "| | | |\n" +
                          "| | | |\n" +
                          "|" + charFiller + "| | |\n";

        assertEquals(expected, actual);
    }
    //Distinction: places a token in the first column on the board

    @Test
    public void placeToken_middle_column_board(){
        char charFiller = 'O';
        int middleCol = 1;
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, middleCol);
        String actual = test.toString();
        String expected = "|0|1|2|\n" +
                          "| | | |\n" +
                          "| | | |\n" +
                          "| |" + charFiller + "| |\n";

        assertEquals(expected, actual);
    }
    //Distinction: places a token in a middle column on the board

    @Test
    public void placeToken_last_column_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, IGameBoard.MIN_COLUMNS - 1);
        String actual = test.toString();
        String expected = "|0|1|2|\n" +
                "| | | |\n" +
                "| | | |\n" +
                "| | |" + charFiller + "|\n";

        assertEquals(expected, actual);
    }
    //Distinction: places a token in the last column on the board

    @Test
    public void placeToken_more_than_one_first_column_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, 0);
        test.placeToken(charFiller, 0);
        String actual = test.toString();
        String expected = "|0|1|2|\n" +
                "| | | |\n" +
                "|" + charFiller + "| | |\n" +
                "|" + charFiller + "| | |\n";

        assertEquals(expected, actual);
    }
    //Distinction: places a token in the first column on the board

    @Test
    public void placeToken_fill_one_column_board(){
        char charFiller = 'O';
        IGameBoard test = makeIGameBoard(IGameBoard.MIN_ROWS, IGameBoard.MIN_COLUMNS, IGameBoard.MIN_NUM_TO_WIN);
        test.placeToken(charFiller, 0);
        test.placeToken(charFiller, 0);
        test.placeToken(charFiller, 0);
        String actual = test.toString();
        String expected = "|0|1|2|\n" +
                "|" + charFiller + "| | |\n" +
                "|" + charFiller + "| | |\n" +
                "|" + charFiller + "| | |\n";

        assertEquals(expected, actual);
    }
    //Distinction: places multiple tokens in the first column on the board until it's full

}