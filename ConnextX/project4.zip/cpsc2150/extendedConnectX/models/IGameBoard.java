package cpsc2150.extendedConnectX.models;

/**
 * Description: IGameBoard interface
 *      This interface holds the default, primary, and secondary methods that are a part of a game. This
 *      interface also holds the contracts for those methods, code for the default methods, and an overall
 *      description of the interface specifications for the game.
 *
 * interface specifications
 * @initialization ensures
 *  [an empty board of size of at most MAX_ROWS X MAX_COLUMNS
 *  and at least MIN_ROWS X MIN_COLUMNS that holds characters]
 *
 * @defines
 *  [self is some 2D structure of characters of size less than MAX_ROWS X MAX_COLUMNS
 *  and greater than MIN_ROWS X MIN_COLUMNS] and
 *  MAX_ROWS [an element of] N and
 *  MAX_COLUMNS [an element of] N and
 *  MAX_NUM_TO_WIN [an element of] N and
 *  MIN_ROWS [an element of] N and
 *  MIN_COLUMNS [an element of] N and
 *  MIN_NUM_TO_WIN [an element of] N
 *
 * @constraints
 *  |self| >= MIN_ROWS * MIN_COLUMNS and |self| <= MAX_ROWS * MAX_COLUMNS
 *
 * */
public interface IGameBoard {
    int MIN_ROWS = 3;
    int MIN_COLUMNS = 3;
    int MIN_NUM_TO_WIN = 3;
    int MAX_ROWS = 100;
    int MAX_COLUMNS = 100;
    int MAX_NUM_TO_WIN = 25;

    //CLASS METHODS
    /**
     * Description: checkIfFree
     *      This function will check to see if column c is available to place a token in
     *
     * @param
     *      c: the column that will be checked
     *
     * @pre
     *      c >= 0 and c < MAX_COLUMNS
     *
     * @post
     *       self = #self
     *
     * @return
     *      true iff board[0][c] = ' ', false otherwise
     *
     */
    default boolean checkIfFree(int c){
        //returns if there is an empty position at the top of the board column.
        //This means no other tokens can be dropped if the column is filled completely with tokens
        return isPlayerAtPos(new BoardPosition(0,c), ' ');
    }
    //END OF CHECKIFFREE METHOD





    /**
     * Description: checkForWin
     *      checks the last placed token for a vertical, horizontal, and diagonal win and returns true if either way
     *      of winning is achieved.
     *
     *      Document Description:
     *          this function will check to see if the last token placed in column c resulted in the player winning the
     *          game. If so it will return true, otherwise false. Note: this is not checking the entire board for a win,
     *          it is just checking if the last token placed results in a win. You may call other methods to complete
     *          this method.
     *
     * @param
     *      c: the column that will be checked for vertical, horizontal, and diagonal wins
     *
     * @pre
     *      c >= 0 and c <= MAX_COLUMNS
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff [horizontal, vertical, or diagonal wins are true] and false otherwise
     *
     */
    default boolean checkForWin(int c){
        int i = 0;
        //pos is at the top of the board
        BoardPosition pos = new BoardPosition(i, c);

        //find the last dropped token/first token from the top
        //checks this by looping until the empty character IS NOT found, which was placed from there as a filler
        //from the constructor
        while(isPlayerAtPos(pos, ' ')){
            ++i;
            pos = new BoardPosition(i, c);
        }
        //checks to see if pos is still a valid position on the board
        if(pos.getRow() >= 0 && pos.getRow() < getNumRows() && pos.getColumn() >= 0 &&
                pos.getColumn() < getNumColumns()){
            //checks all possible winning conditions (vertical, diagonal, horizontal)
            return checkHorizWin(pos, whatsAtPos(pos)) || checkVertWin(pos, whatsAtPos(pos)) ||
                    checkDiagWin(pos, whatsAtPos(pos));
            //anything pass this is false
        }
        return false;
    }
    //END OF CHECKFORWIN METHOD



    /**
     * Description: checkTie
     *      This function checks to see if all board columns are full and nobody has one the game yet
     *
     *      Document Description:
     *          this function will check to see if the game has resulted in a tie. A game is tied if there are no free
     *          board positions remaining. You do not need to check for any potential wins because we can assume that
     *          the players were checking for win conditions as they played the game. It will return true if the game
     *          is tied and false otherwise.
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff [all positions on the board are taken]
     *
     */
    default boolean checkTie(){
        for(int i = 0; i < getNumColumns(); ++i){
            if(checkIfFree(i)){
                return false;
            }
        }
        return true;
    }
    //END OF CHECKTIE METHOD



    /**
     * Description: checkHorizWin
     *      This function checks for a horizontal win by checking consecutive locations on the same row as the
     *      last placed token.
     *
     *      Document Description:
     *          checks to see if the last token placed (which was placed in position pos by player p) resulted in 5 in
     *          a row horizontally. Returns true if it does, otherwise false.
     *
     * @param
     *      pos: the BoardPosition that will be used as a point of reference for horizontal token checkings
     *
     *      p: that character that will be used as the main character of comparison at each token check.
     *
     * @pre
     *      [BoardPosition pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff [consecutive horizontal BoardPositions that hold the character p (including the BoardPosition pos)]
     *      >= getNumToWin()
     *
     */
    default boolean checkHorizWin(BoardPosition pos, char p){
      
        int consecutiveTokens = 1;
        int i = 1;
        //checks left of pos
        while(isPlayerAtPos(new BoardPosition(pos.getRow(), pos.getColumn() - i), p)){
            ++consecutiveTokens;
            ++i;
        }
        //resets back to 1 away from pos
        i = 1;

        //checks right of pos
        while(isPlayerAtPos(new BoardPosition(pos.getRow(), pos.getColumn() + i), p)){
            ++consecutiveTokens;
            ++i;
        }

        //checks total consecutive tokens away from pos
        return consecutiveTokens >= getNumToWin();
    }
    //END OF CHECKHORIZWIN METHOD



    /**
     * Description: checkVertWin
     *      This function checks for a vertical win by checking consecutive locations in the same column and below the
     *      last placed token on the board
     *
     *      Document Description:
     *          checks to see if the last token placed (which was placed in position pos by player p) resulted in 5 in
     *          a row vertically. Returns true if it does, otherwise false.
     *
     * @param
     *      pos: the last placed token position on the board
     *
     *      p: the character that will be used to compare each consecutive positions below the BoardPosition pos in the
     *      same column
     *
     * @pre
     *      [pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff whatsAtPos([consecutive BoardPositions below pos and in the same column]) = p and [number of
     *      vertical positions below BoardPosition pos that equal p] >= getNumToWin()
     */
    default boolean checkVertWin(BoardPosition pos, char p){

        int consecutiveTokens = 1;
        int i = 1;
        //checks consecutive vertical positions below pos with the same character at pos
        while(isPlayerAtPos(new BoardPosition(pos.getRow() + i, pos.getColumn()), p)){
            ++consecutiveTokens;
            ++i;
        }

        //checks for the vertical win and then returns false otherwise
        return consecutiveTokens >= getNumToWin();
    }
    //END OF CHECKVERTWIN METHOD



    /**
     * Description: checkDiagWin
     *      This function checks diagonals below a BoardPosition pos for consecutive characters p
     *
     *      Document Description:
     *          checks to see if the last token placed (which was placed in position pos by player p) resulted in 5 in
     *          a row diagonally. Returns true if it does, otherwise false.
     *
     *          Note: there are two diagonals to check
     *
     * @param
     *      pos: the BoardPosition that will be used as a reference point for the bottom left and right diagonals
     *
     *      p: the character that will be used to compare each consecutive diagonal check with.
     *
     * @pre
     *      [pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff ([bottom left diagonals starting at BoardPosition pos are at least continuously equal to char p
     *      for getNumToWin() times] || [bottom left diagonals starting at BoardPosition pos are at least
     *      continuously equal to char p for getNumToWin() times])
     *
     */
    default boolean checkDiagWin(BoardPosition pos, char p){

        int consecutiveTokens = 1;
        int i = 1;
        //adds left down consecutive diagonal from pos
        while(isPlayerAtPos(new BoardPosition(pos.getRow() + i, pos.getColumn() - i), p)){
            consecutiveTokens++;
            i++;
        }

        //resets loop for right up diagonal
        i = 1;

        //adds consecutive right diagonal positions from pos for the same character at pos upwards
        while (isPlayerAtPos(new BoardPosition(pos.getRow() - i, pos.getColumn() + i), p)){
            ++i;
            consecutiveTokens++;
        }

        //checks the full right diagonal win condition in both directions
        if(consecutiveTokens >= getNumToWin()){
            return true;
        }


        //resets loop for left up diagonal
        i = 1;
        consecutiveTokens = 1;

        //adds consecutive left diagonal positions from pos for the same character at pos upwards
        while (isPlayerAtPos(new BoardPosition(pos.getRow() - i, pos.getColumn() - i), p)){
            ++i;
            consecutiveTokens++;
        }

        i = 1;

        //adds consecutive right diagonal positions from pos for the same character at pos downward
        while (isPlayerAtPos(new BoardPosition(pos.getRow() + i, pos.getColumn() + i),p)){
            ++i;
            consecutiveTokens++;
        }

        //checks the full left diagonal win condition in both directions
        if(consecutiveTokens >= getNumToWin()){
            return true;
        }


        //checks the right up diagonal win condition
        // and returns false otherwise since
        // all other possibilities have been checked
        return consecutiveTokens >= getNumToWin();
    }
    //END OF CHECKDIAGWIN METHOD


    /**
     * Description: isPlayerAtPos
     *      This function checks to see if a character is at a specific BoardPosition on the board
     *
     *      Document Description:
     *          returns true if the player is at pos; otherwise, it returns false.
     *          Note: this method will be implemented very similarly to whatsAtPos,
     *          but it's asking a different question. We only know they will be
     *          similar because we know GameBoard will contain a 2D array. If the
     *          data structure were to change in the future, these two methods
     *          could be radically different.
     *
     * @param
     *      pos: the BoardPosition that will be checked on the board
     *
     *      player: the character that will be used to compare the character on the board at the BoardPosition pos
     *
     * @pre
     *      [pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      true iff whatsAtPos(pos) = player
     *
     */
    default boolean isPlayerAtPos(BoardPosition pos, char player){
        //a simplified version that
        // gets the character at pos then
        // checks if it is equal to player
        return whatsAtPos(pos) == player;
    }
    //END OF ISPLAYERATPOS METHOD



    //Non-default methods
    /**
     * Description: whatsAtPos
     *      This function returns the character that is at a specific BoardPosition on the board
     *
     *      Document Description:
     *          returns what is in the GameBoard at position pos If no marker is there, it returns a blank space char.
     *
     * @param
     *      pos: the BoardPosition that will be used to find the location on the board to get that specific character
     *
     * @pre
     *      [pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      [the character located at that BoardPosition pos on the board]
     *
     */
    char whatsAtPos(BoardPosition pos);

    /**
     * Description: placeToken
     *      This function adds a character c into the board at the first empty position on the board.
     *
     *      Document Description:
     *          places the character p in column c. The token will be placed in the lowest available row in column c.
     *
     * @param
     *      p: the character that will be added
     *
     *      c: the column that will be checked to find the first empty position on the board.
     *
     * @pre
     *      c >= 0 and c < MAX_COLUMNS and (p = 'X' || p = 'O')
     *
     * @post
     *      [the character p will be added to the first empty row in the board[first empty row][c]]
     *
     */
    void placeToken(char p, int c);

    /**
     * Description: getNumRows()
     *      returns the number of rows in the GameBoard
     *
     * @post
     * self = #self and getNumRows() >= MIN_ROWS and getNumRows() <= MAX_ROWS
     *
     * @return
     *  getNumRows() = self.getNumRows();
     *
     * */
    int getNumRows();

    /**
     * description getNumColumns
     *  returns the constant integer that is the number of columns on the board of the implementation of this interface
     *
     * @post
     * self = #self and getNumColumns() >= MIN_COLUMNS and getNumColumns() <= MAX_COLUMNS
     *
     * @return
     *  getNumColumns() = self.getNumColumns()
     *
     * */
    int getNumColumns();

    /**
     * description getNumToWin
     *  returns the constant integer that is the number of consecutive items needs to win
     *
     * @post
     * self = #self and getNumToWin() >= MIN_NUM_TO_WIN and getNumToWin() <= MAX_NUM_TO_WIN
     *
     * @return
     *  getNumToWin() = self.getNumToWin();
     *
     * */
    int getNumToWin();
}
