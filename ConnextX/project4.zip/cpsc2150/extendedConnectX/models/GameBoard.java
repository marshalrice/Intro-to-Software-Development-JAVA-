package cpsc2150.extendedConnectX.models;

/**
 * @invariants
 *
 * @correspondence
 *       board = char[MAX_ROWS][MAX_COLUMNS] && getNumRows() = MAX_ROWS and getNumColumns() = MAX_COLUMNS and
 *       getNumToWin() = NUM_TO_WIN
 */
public class GameBoard extends AbsGameBoard implements IGameBoard{

    //CLASS VARIABLES
    private final int CUR_ROWS;
    private final int CUR_COLUMNS;
    private final int CUR_NUM_TO_WIN;
    private final char[][] board;

    //CONSTRUCTOR
    /**
     * Description GameBoard constructor
     *      This is a constructor that creates the board and initializes all entries to the space character
     * @param
     *      r: the number of rows for the board
     *      c: the number of columns for the new board
     *       tfw: the number of tokens in a row to win on the new board
     * @pre
     *      r >= 0 and r <
     * @post
     *      board = char[MAX_ROWS][MAX_COLUMNS] and board[0...MAX_ROWS - 1][0...MAX_COLUMNS - 1] = ' '
     *
     */
    public GameBoard(int r, int c, int tfw){
        CUR_ROWS = r;
        CUR_COLUMNS = c;
        CUR_NUM_TO_WIN = tfw;
        //declares board array
        board = new char[getNumRows()][getNumColumns()];

        //initializes board
        for(int i = 0; i < getNumRows(); ++i){
            for(int j = 0; j < getNumColumns(); ++j){
                board[i][j] = ' ';
            }
        }
    }
    //END OF GAMEBOARD CONSTRUCTOR


    //CLASS METHODS

    /**
     * Description placeToken
     *      This function adds a character c into the board at the first empty position on the board.
     *
     * @param
     *      p: the character that will be added
     *
     *      c: the column that will be checked to find the first empty position on the board.
     *
     * @pre
     *      c >= 0 and c < MAX_COLUMNS and (p = 'X' || p = 'O')
     *
     * @post
     *      [the character p will be added to the first empty row in the board[first empty row][c]]
     *
     */
    public void placeToken(char p, int c){

        /*
        places the character p in column c. The token will be placed in
        the lowest available row in column c.
        */
        for(int i = getNumRows() - 1; i >= 0; --i){
            if(whatsAtPos(new BoardPosition(i, c)) == ' '){
                board[i][c] = p;
                break;
            }
        }
    }
    //END OF PLACETOKEN METHOD


    /**
     * Description: whatsAtPos
     *      This function returns the character that is at a specific BoardPosition on the board
     *
     * @param
     *      pos: the BoardPosition that will be used to find the location on the board to get that specific character
     *
     * @pre
     *      [pos is a valid position on the board]
     *
     * @post
     *      self = #self
     *
     * @return
     *      board[pos.getRow()][pos.getColumn()]
     *
     */
    public char whatsAtPos(BoardPosition pos){

        if(pos.getRow() >= 0 && pos.getColumn() >= 0 && pos.getRow() < getNumRows() &&
                pos.getColumn() < getNumColumns()){
            return board[pos.getRow()][pos.getColumn()];
        }
        return ' ';
    }
    //END OF WHATSATPOS METHOD


    public int getNumRows(){
        return CUR_ROWS;
    }
    public int getNumColumns(){
        return CUR_COLUMNS;
    }
    public int getNumToWin(){
        return CUR_NUM_TO_WIN;
    }

    //END OF GAMEBOARD CLASS
}
