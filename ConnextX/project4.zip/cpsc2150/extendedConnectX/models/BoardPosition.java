package cpsc2150.extendedConnectX.models;

public class BoardPosition {
    private final int row;
    private final int column;


    /**
     * Description: BoardPosition constructor
     *      This is the constructor of BoardPosition that will be called to create a BoardPosition object.
     *      Every object will hold two integers. One holding the value of a row and the other holding the value of
     *      a column.
     *
     * @pre
     *      r >= 0 and c >= 0
     * @param
     *      r:  The row for the BoardPosition object
     *
     *      c:  The column for the BoardPosition object
     *
     * @post
     *      row = r and column = c
     *
     * */
    public BoardPosition(int r, int c){
        row = r;
        column = c;
    }

    /**
     * Description: getRow
     *      getRow is a function that returns the row of this BoardPosition object.
     *
     * @post
     *      self = #self
     *
     * @return
     *      getRow() = row
     *
     * */
    public int getRow(){
        return row;
    }

    /**
     * Description: getColumn
     *      getColumn is a function that returns the column of this BoardPosition object.
     *
     * @post
     *      self = #self
     *
     * @return
     *      getColumn() = column
     *
     * */
    public int getColumn(){
        return column;
    }

    /**
     * Description: equals
     *
     * @param
     *      obj: the Object that will be compared with this Object
     * @pre
     *     obj instanceOf BoardPosition
     *
     * @post
     *      self = #self
     * @return
     *      True iff (obj instanceOf BoardPosition) AND (((BoardPosition)obj).getRow() == this.getRow()) AND
     *      (((BoardPosition)obj).getColumn() == this.getColumn()).
     * */
    @Override
    public boolean equals(Object obj){
        if(obj instanceof BoardPosition Obj){
            return Obj.getColumn() == this.getColumn() && Obj.getRow() == this.getRow();
        }
        return false;
    }

    /**
     * Description: toString
     *      returns a String representation of this BoardPosition object
     * @post
     *     self = #self
     * @return
     *      [a String representation of this BoardPosition object]
     * */
    @Override
    public String toString(){
        return this.getRow() + "," + this.getColumn();
    }
}
