package cpsc2150.extendedConnectX.models;

import java.util.*;
/*
*   int MIN_ROWS = 3;
    int MIN_COLUMNS = 3;
    int MIN_NUM_TO_WIN = 3;
    int MAX_ROWS = 100;
    int MAX_COLUMNS = 100;
    int MAX_NUM_TO_WIN = 25;
* */
/**
 * @invariant
 *     |board| >= 0 and |board| <= MAX_ROWS * MAX_COLUMNS and CUR_ROWS >= MIN_ROWS and CUR_ROWS <= MAX_ROWS
 *     and CUR_COLUMNS >= MIN_COLUMNS and CUR_COLUMNS <= MAX_COLUMNS and CUR_NUM_TO_WIN >= MIN_NUM_TO_WIN and
 *     CUR_NUM_TO_WIN <= MAX_NUM_TO_WIN
 *
 * @correspondence
 *      board = self
 *
 * */
public class GameBoardMem extends AbsGameBoard implements IGameBoard {
    private final Map<Character, List<BoardPosition>> board;
    private final int CUR_NUM_TO_WIN;
    private final int CUR_COLUMNS;
    private final int CUR_ROWS;

    /**
     * Description: GameBoardMem
     *      This is the constructor that creates the GameBoardMem object
     *
     * @param
     *      new_Rows: the new integer for CUR_ROWS
     *
     *      new_Columns: the new integer for CUR_COLUMNS
     *
     *      new_Num_To_Win: the new integer for CUR_NUM_TO_WIN
     *
     * @pre
     *      new_Rows >= MIN_ROWS and new_Rows <= MAX_ROWS and new_Columns >= MIN_ROWS and new_Columns <= MAX_COLUMNS
     *      and new_Num_To_Win >= MIN_NUM_TO_WIN and new_Num_To_Win <= MAX_NUM_TO_WIN
     *
     * @post
     *      CUR_ROWS = new_Rows and CUR_COLUMNS = new_Columns and CUR_NUM_TO_WIN = new_Num_To_Win
     *      and board = new Hashmap<>()
     *
     * */
    public GameBoardMem(int new_Rows, int new_Columns, int new_Num_To_Win) {
        CUR_ROWS =  new_Rows;
        CUR_COLUMNS = new_Columns;
        CUR_NUM_TO_WIN = new_Num_To_Win;
        board = new HashMap<>();
    }


    @Override
    public char whatsAtPos(BoardPosition pos) {
        //for every player recognized on the board
        for(Character player: board.keySet()){
            //check if their token was placed at BoardPosition pos
            if(board.get(player).contains(pos)){
                //if BoardPosition pos was found, return that players token
                return player;
            }
        }
        //This means pos is empty or is not a valid token on the board
        return ' ';
    }


    @Override
    public void placeToken(char p, int c) {
        //add the Character to the board if not already recognized
        if(!board.containsKey(p)){
            board.put(p, new ArrayList<>());
        }
        //adds a new BoardPosition to their respective key
        if(checkIfFree(c)){
            board.get(p).add(new BoardPosition(CUR_ROWS - board.get(p).size() - 1, c));
        }
    }

    @Override
    public int getNumRows() {
        return CUR_ROWS;
    }


    @Override
    public int getNumColumns() {
        return CUR_COLUMNS;
    }


    @Override
    public int getNumToWin() {
        return CUR_NUM_TO_WIN;
    }
}
